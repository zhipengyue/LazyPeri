# 懒人外设：macOS USB 授权与连接指南

适用于通过 USB 数据线将 Android 手机上的“懒人外设”连接到 Mac。仅插入数据线不会使普通 Android 手机自动成为 USB 鼠标；Mac 上需要运行本项目的 USB Bridge。

## 1. 授权手机的 USB 调试

1. 在手机的“开发者选项”中开启 **USB 调试**。不同品牌的入口可能不同；如尚未显示“开发者选项”，通常需在“关于手机”中连续点击版本号。
2. 用支持数据传输的 USB 线连接 Mac，解锁手机。
3. 手机弹出“允许 USB 调试？”时，核对是自己的电脑，再点“允许”。若没有弹窗，可重新插拔数据线，并在终端运行 `adb devices` 查看状态。`unauthorized` 表示仍需在手机上确认授权。

## 2. 授权 Mac 控制鼠标和键盘

1. 打开 **苹果菜单  → 系统设置 → 隐私与安全性 → 无障碍**。某些系统语言或版本把这里显示为“辅助功能”。请进入“隐私与安全性”中的权限列表，而不是系统设置侧边栏的“辅助功能”。
2. 找到 **终端（Terminal）**，打开右侧开关。如果列表中没有终端，点击列表下方的 **“+”**，选择“终端”App 并添加。按提示输入 Mac 密码或使用 Touch ID。
3. 按 **⌘Q** 完全退出终端，再重新打开终端。如果你通过 Codex 或其他终端程序启动 Bridge，应该授权**实际运行脚本的那个程序**，然后完全退出并重开该程序。

这项权限由 macOS 要求电脑用户亲自批准。Bridge 启动时会检查权限；如果仍显示“未授予辅助功能权限”，请确认授权对象和运行脚本的程序一致。

## 3. 启动并测试

1. 在手机上打开“懒人外设”。Mac 需已安装 Python 3 和 Android Platform Tools（`adb`）。
2. 在 Mac 上从 [GitHub 下载 macOS 全功能桥接 ZIP](https://raw.githubusercontent.com/zhipengyue/LazyPeri/main/releases/懒人外设-macOS-全功能-USB-Bridge.zip)，解压后双击其中的 `start-usb-mac.command`。保持终端窗口开启。
3. 正常时依次看到 **“macOS 辅助功能权限已确认。”**、**“USB Bridge 已就绪。”**、**“触摸板已连接。”**
4. 在 Mac 上打开“文本编辑”等普通应用，先点入文本框，再在手机上移动指针或发送文字。文字发往电脑当前获得输入焦点的位置。

## 常见问题

- **找不到 adb**：安装 Android Platform Tools，并把 `adb` 加入 PATH，或安装 Android Studio 的 SDK Platform Tools。
- **需要恰好一台已授权的 Android 设备**：运行 `adb devices`。请只连接一台调试设备；`unauthorized` 时在手机上允许 USB 调试；未列出设备时检查数据线、手机的 USB 模式和连接。
- **Bridge 已就绪，但没有“触摸板已连接”**：确认手机应用已经打开，USB 数据线未断开，并重新启动 Bridge。
- **提示辅助功能权限不足**：给实际运行脚本的终端或 Codex 授权，完全退出后重新打开，再启动 Bridge。
- **显示已连接但文字未进入电脑**：先点击电脑目标文本框并保持其处于前台；部分应用可能不接受模拟键盘输入，可先用“文本编辑”验证。

参考：[Apple：允许无障碍 App 访问你的 Mac](https://support.apple.com/zh-cn/guide/mac-help/mh43185/27/mac/27)、[Android：在硬件设备上运行应用及 RSA 调试授权](https://developer.android.com/studio/run/device)。
